import { useState } from 'react'
import Titulo from './components/Titulo'
import Card from './components/Card'
import Usuarios from './components/usuarios'

function App() {
  const [count, setCount] = useState(0);

  return (
    <>
      <div>
        <Titulo texto="Aula de React + API Pública" />

        <Card
          titulo="Contador de Cliques"
          descricao={`Valor Atual: ${count}`}
        />

        <button onClick={() => setCount(count + 1)}>+</button>
        <button onClick={() => setCount(count - 1)}>-</button>

        <hr />

        <Usuarios />
      </div>
    </>
  );
}

export default App
