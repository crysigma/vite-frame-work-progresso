import { useState, useEffect } from "react";

export default function Usuarios() {
    const [usuarios, setUsuarios] = useState([]);

    useEffect(() => {
        fetch("https://jsonplaceholder.typicode.com/users")
            .then((res) => res.json())
            .then((data) => setUsuarios(data))
            .catch((err) => console.log("Erro ao buscar a API:", err));
    }, []);

    return (
        <div>
            <h3>Usuários da API Pública</h3>

            <ul>
                {usuarios.map((u) => (
                    <li key={u.id}>
                        <p>
                            {u.name} - {u.email}
                        </p>
                    </li>
                ))}
            </ul>
        </div>
    );
}
