export default function Titulo({ texto }) {
    return (
        <h1 style={{ color: '#00838f' }}>
            {texto}
        </h1>
    );
}
