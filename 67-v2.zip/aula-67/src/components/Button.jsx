function Button({
    children,
    onClick,
    variant = "primary",
    type = "button"
}) {
    return (
        <button
            type={type}
            className={`button ${variant}`}
            onClick={onClick}
        >
            {children}
        </button>
    )
}
export default Button