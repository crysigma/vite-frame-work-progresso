import Button from "./Button";
import { useState } from "react";

function TaskForm({ onAdd }){
    const [title, setTitle] = useState("");
    function handleSubmit(event){
        event.preventDefault();
        const cleanTitle = title.trim();
        if(!cleanTitle) return;
            onAdd(cleanTitle);
            setTitle("");
    }
    return(
        <form className="task-form" onSubmit={handleSubmit}>
            <input 
            value={title}
            onChange={(event) => setTitle(event.target.value)}
            placeholder="Digite o Título da sua Tarefa"
            />
            <Button type="submit">
                Adicionar
            </Button>
        </form>
    );
}

export default TaskForm;