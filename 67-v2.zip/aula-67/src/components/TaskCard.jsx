import Button from "./Button";

function TaskCard({ task, onToggle, onDelete }) {
    return (
        <article className={`task-card, ${task.completed ? "completed" : ""}`}>
            <div>
                <h3>{task.title}</h3>
                <p>{task.completed ? "Concluída" : "Pendente"}</p>
            </div>
            <div className="actions">
                <Button onClick={() => onToggle(task.id)}>
                    <p>
                        {task.completed ? "Reabrir" : "Concluir"}
                    </p>
                </Button>

                <Button variant="danger"
                    onClick={() => onDelete(task.id)}>
                    Excluir
                </Button>
            </div>
        </article>
    );
}
export default TaskCard;