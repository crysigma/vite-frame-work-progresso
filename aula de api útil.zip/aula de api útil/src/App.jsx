import { useEffect, useState } from "react";
import "./App.css";
const API = "https://jsonplaceholder.typicode.com";
function App() {
  const [posts, setPosts] = useState([]);
  const [usuarios, setUsuarios] = useState([]);
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState("");
  const [selecionado, setSelecionado] = useState(null);
  const [comentarios, setComentarios] = useState([]);
  const [titulo, setTitulo] = useState("");
  const [texto, setTexto] = useState("");
  const [mensagem, setMensagem] = useState("");
  useEffect(() => {
    async function carregar() {
      try {
        const [rp, ru] = await Promise.all([
          fetch(`${API}/posts`), fetch(`${API}/users`)
        ]);
        if (!rp.ok || !ru.ok) throw new Error("Erro ao buscar dados.");
        const dadosPosts = await rp.json();
        const dadosUsuarios = await ru.json();
        setPosts(dadosPosts.slice(0, 10));
        setUsuarios(dadosUsuarios);
      } catch (e) {
        setErro(e.message);
      } finally {
        setCarregando(false);
      }
    }
    carregar();
  }, []);
  async function abrirDetalhes(post) {
    setSelecionado(post);
    setComentarios([]);
    try {
      const r = await fetch(`${API}/posts/${post.id}/comments`);
      setComentarios(await r.json());
    } catch {
      setMensagem("Não foi possível carregar comentários.");
    }
  }
  async function criarPublicacao(event) {
    event.preventDefault();
    setMensagem("");
    if (!titulo.trim() || !texto.trim()) {
      setMensagem("Preencha título e texto.");
      return;
    }
    try {
      const r = await fetch(`${API}/posts`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title: titulo, body: texto, userId: 1 })
      });
      if (!r.ok) throw new Error("Falha ao publicar.");
      const dados = await r.json();
      setPosts((lista) => [{ ...dados, id: Date.now(), userId: 1 }, ...lista]);
      setTitulo("");
      setTexto("");
      setMensagem("Publicado! (Demonstração: não fica salvo na API.)");
    } catch (e) {
      setMensagem(e.message);
    }
  }
  function autor(userId) {
    const u = usuarios.find((item) => item.id === userId);
    return u ? u.name : "Autor da demonstração";
  }
  if (carregando) return <main className="container">Carregando mural...</main>;
  if (erro) return <main className="container">{erro}</main>;
  return (
    <main className="container">
      <header className="topo">
        <span>MURAL DIGITAL</span>
        <h1>Publicações</h1>
        <p>Leia ideias e compartilhe uma publicação fictícia.</p>
      </header>
      <section className="painel">
        <h2>Criar publicação</h2>
        <form onSubmit={criarPublicacao}>
          <input value={titulo}
            onChange={(e) => setTitulo(e.target.value)}
            placeholder="Título da publicação" />
          <textarea value={texto}
            onChange={(e) => setTexto(e.target.value)}
            placeholder="Escreva sua publicação..." rows="3" />
          <button type="submit">Publicar</button>
        </form>
        {mensagem && <p className="mensagem">{mensagem}</p>}
      </section>
      <section>
        <h2>Últimas publicações</h2>
        <div className="lista">
          {posts.map((post) => (
            <article className="post" key={post.id}>
              <small>{autor(post.userId)}</small>
              <h3>{post.title}</h3>
              <p>{post.body}</p>
              <button onClick={() => abrirDetalhes(post)}>
                Ver detalhes e comentários
              </button>
            </article>
          ))}
        </div>
      </section>
      {selecionado && (
        <section className="detalhes">
          <button className="fechar" onClick={() => setSelecionado(null)}>
            Fechar
          </button>
          <h2>{selecionado.title}</h2>
          <p>{selecionado.body}</p>
          <h3>Comentários</h3>
          {comentarios.length === 0 ? <p>Carregando comentários...</p> :
            comentarios.slice(0, 5).map((c) => (
              <div className="comentario" key={c.id}>
                <strong>{c.name}</strong><p>{c.body}</p>
              </div>
            ))}
        </section>
      )}
    </main>
  );
}
export default App;