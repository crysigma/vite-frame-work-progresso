import { useState, useEffect } from 'react';

export default function App() {
  // Estados da aplicação
  const [estados, setEstados] = useState([]);
  const [siglaSelecionada, setSiglaSelecionada] = useState('');
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState(null);

  // Efeito para carregar os estados da API do IBGE ao montar o componente
  useEffect(() => {
    async function buscarEstados() {
      try {
        setCarregando(true);
        const resposta = await fetch(
          'https://servicodados.ibge.gov.br/api/v1/localidades/estados?ordenacao=ASC'
        );
        if (!resposta.ok) throw new Error('Falha ao carregar os dados.');
        
        const dados = await resposta.json();
        setEstados(dados);
      } catch (err) {
        // CORREÇÃO: A string foi unificada na mesma linha para evitar erro de sintaxe
        setErro('Não foi possível conectar à API do IBGE. Verifique a internet.');
      } finally {
        setCarregando(false);
      }
    }
    buscarEstados();
  }, []);

  // Busca o objeto do estado selecionado a partir da sigla escolhida
  const estadoAtual = estados.find((e) => e.sigla === siglaSelecionada);

  return (
    <div className="container">
      <h1>🇧🇷 Explorador de Estados Brasileiros</h1>

      {/* Exibição condicional de carregamento e erros */}
      {carregando && <p className="loading">Carregando estados do IBGE...</p>}
      {erro && <p className="error">{erro}</p>}

      {/* Menu Seletor de Estados */}
      {!carregando && !erro && (
        <div className="form-group">
          <label htmlFor="select-estado">Selecione um Estado:</label>
          <select
            id="select-estado"
            value={siglaSelecionada}
            onChange={(e) => setSiglaSelecionada(e.target.value)}
          >
            <option value="">-- Escolha um estado na lista --</option>
            {estados.map((est) => (
              <option key={est.id} value={est.sigla}>
                {est.nome} ({est.sigla})
              </option>
            ))}
          </select>
        </div>
      )}

      {/* Detalhes do Estado Selecionado */}
      {estadoAtual && (
        <div className="card">
          <h2>{estadoAtual.nome}</h2>
          {/* CORREÇÃO: Corrigido de "infoitem" para "info-item" para manter o padrão */}
          <p className="info-item">
            <strong>Sigla:</strong> {estadoAtual.sigla}
          </p>
          <p className="info-item">
            <strong>Região:</strong> {estadoAtual.regiao?.nome}
          </p>
          <p className="info-item">
            <strong>ID IBGE:</strong>{' '}
            <span className="badge-id">{estadoAtual.id}</span>
          </p>
        </div>
      )}
    </div>
  );
}
