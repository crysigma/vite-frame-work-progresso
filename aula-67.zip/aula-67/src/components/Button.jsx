function Button({
    children,
    OnClick,
    variant = "Primary",
    type = "button"
}){
    return (
        <button type={type}
        className={`button ${variant}`}
        onClick={OnClick}>
             {children} 
        
         </button>
    )
}
export default Button;