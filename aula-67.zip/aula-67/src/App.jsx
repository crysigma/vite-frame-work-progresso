import { useState } from 'react'
import Header from "./components/Header"
import Button from "./components/Button"



function App() {

  return (
    <>
      <Header/>
      <Button>Adicionar</Button>
      <Button variant="danger">
        Excluir
        </Button>
    </>
  )
}

export default App
