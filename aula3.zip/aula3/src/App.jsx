import { useState } from 'react'

function App() {
  const [nome, setNome] = useState("")
  const [resultado, setResultado] = useState("")

  function mostrartexto (){
    setResultado(nome);
  }

  function ocultar (){
    setResultado("");
  }


  return (
    <>
      <input type="text" value={nome} onChange={(e) => setNome(e.target.value)} />

    <button onClick={mostrartexto}> exibir Nome</button>
    <button onClick={ocultar}>limpar</button>

    <h1>olá {resultado}</h1>

    </>
  )
}

export default App
