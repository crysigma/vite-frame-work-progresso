import {useState, useEffect } from "react";

export default function App() {
  const [livros, setLivros] = useState([]);
  const [carregando,setCarregando] = useState(true);

  useEffect(() => {fetch("https://openlibrary.org/search.json?q=fantasy&limit=8")
    .then((resposta) => resposta.json())
    .then ((dados) => {
      setLivros(dados.docs);
      setCarregando(false);
    })
    .catch((erro) => {console.log("Erro ao buscar os livros na API!", erro); 
    setCarregando(false);
    });
  }, []);
  return(
    <div className="container">
      <header>
        <h1>Biblioteca Digital de Livros</h1>
        <p>API pública de Livros</p>
      </header>

      <main>
      <h2>Livros em destaques</h2>
      {carregando ? (<p>Livros...</p>) : (
          <div className="grade-livros">
{livros.map((livro) => (
  <div className="card-livro" key={livro.key}>
    {livro.cover_i ? (
      <img
        src={`https://covers.openlibrary.org/b/id/${livro.cover_i}-M.jpg`}
        alt={`Capa do livro ${livro.title}`}
      />
    ) : (
      <div className="sem-capa">Sem capa</div>
    )}
  </div>
))}
          </div>
      )}
      </main>
    </div>
  )
}