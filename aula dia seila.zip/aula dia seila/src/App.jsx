import { useState } from 'react'

function Menu(){
  return (
    <nav>
      <a href="">Início</a>
      <a href="">Sobre</a>
      <a href="">Contrato</a>
    </nav>
  )
}

function Rodape(){
return (
  <footer>
    <p>&copy; Meu site 2026</p>
  </footer>
  )
}

function Botao ({texto, link}){
  return(
    <a href={link}>
    <button>{texto}</button>
    </a>
      )
}

function Img(){
  return(
    <img src={imagem} alt=""/>
  )
}

function App() {

  return (
    <>
      <section>
        <h1>Curriculo</h1>
        <Menu/>
        <Botao
        texto="Git Hub"
        link="https://www.google.com/search?q=google&rlz=1C1GCQM_enBR1221BR1221&oq=&gs_lcrp=EgZjaHJvbWUqCQgBECMYJxjqAjIJCAAQIxgnGOoCMgkIARAjGCcY6gIyCQgCECMYJxjqAjIJCAMQIxgnGOoCMgkIBBAjGCcY6gIyCQgFECMYJxjqAjIJCAYQIxgnGOoCMgkIBxAjGCcY6gLSAQsxOTczOTc3ajBqN6gCCLACAfEFMXk43SjaPJg&sourceid=chrome&source=chrome.ob&ie=UTF-8"
        />
        <Botao
        texto="outra coisa"
        link="https://accounts.google.com/v3/signin/accountchooser?client_id=940701876580-svccomhabs1glneou4l5cfp9ulot2nhc.apps.googleusercontent.com&nonce=37f49e5d-7892-4a6a-9a4f-69ff02de5855&redirect_uri=https%3A%2F%2Flogin.appinventor.mit.edu%2Freturn&response_type=code&scope=openid+email&state=b23314be-e306-4897-828f-4caeebab1aec&dsh=S337717695%3A1787854972676759&o2v=2&service=lso&flowName=GeneralOAuthFlow&opparams=%253F&continue=https%3A%2F%2Faccounts.google.com%2Fsignin%2Foauth%2Fv3%2Fconsent%3Fauthuser%3Dunknown%26part%3DAJi8hAN87G_Cun9eayhSafe0nsYFcrIjVjMiSrhz3rfMD1aPNf9zRjhBmcRWqOu9UGNx3QeosI51oK0ZJqcXR0gzgghOyiBMMKleFQo1p0o2cP3kvq_2O08YuX2OkXqvGqk3N-3X2J4SYa7TOjsMAti66RIz8JUdvAl-q_rauok3hzbyqX_c1YM-VtxcdOz_-mD84NazbI3UHklV6rFMAitCX27pl9Goi9MGLrlpWkK-Ik_Hyp-k1KV_OMNZ76Yt-XYIWgunS6G_KH0RvRYWzRNeWsa-Qf-sAdQDiCwR6OHh09ZotpflXDgdhv4D-5MIW203BH5T_sgFtkTEr03XhH_r6_0gTfcTG13sPYJG9GtMF2WqwfPC_HIaWkk8C1bjjMVIzGe4sNxij4ZTbuApEVetKInO627MgEB_p1C4CgfTZy6p0JTK_ofst0utu1kAlBpuTSueSSZ5ymYUZ5yxDekHdk9Luu20Cw%26flowName%3DGeneralOAuthFlow%26as%3DS337717695%253A1787854972676759%26client_id%3D940701876580-svccomhabs1glneou4l5cfp9ulot2nhc.apps.googleusercontent.com%26requestPath%3D%252Fsignin%252Foauth%252Fv3%252Fconsent%23&app_domain=https%3A%2F%2Flogin.appinventor.mit.edu"
        />
        <Img
        imagem=""
        />
        <Rodape/>
      </section>
    </>
  )
}

export default App
