import Stat from "./Stat";

function CharacterCard({ personagem }) {
    return (
        <div className="card">
            <div className="emoji">{personagem.emoji}</div>

            <h2>{personagem.nome}</h2>

            <h3>{personagem.classe}</h3>

            <div className="stats">
                <Stat nome="❤️ Vida" valor={personagem.vida} />
                <Stat nome="⚔️ Ataque" valor={personagem.ataque} />
                <Stat nome="🛡️ Defesa" valor={personagem.defesa} />
                <Stat nome="⚡ Velocidade" valor={personagem.velocidade} />
            </div>
        </div>
    );
}

export default CharacterCard; 