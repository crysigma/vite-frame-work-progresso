function Stat({ nome, valor }) {
    return (
        <div className="stat">
            <span>{nome}</span>
            <strong>{valor}</strong>
        </div>
    );
}

export default Stat;