import { useState } from "react";
import Button from "./components/Button";
import CharacterCard from "./components/CharacterCard";
import Stat from "./components/Stat";

const personagens = [
 {
nome: "fernando",
classe: "guerreiro",
vida: 70,
ataque: 50,
defesa: 60,
velocidade: 30
 },
 {
nome: "Cristhian",
classe: "mago",
vida: 30,
ataque: 70,
defesa: 40,
velocidade: 50
 },
 {
nome: "Crystian",
classe: "Paladino",
vida: 99.9,
ataque: 99.9,
defesa: 99.9,
velocidade: 99.9
 },
 {
nome: "Davi",
classe: "Arqueiro",
vida: 30,
ataque: 70,
defesa: 40,
velocidade: 60
 },
 {
nome: "Hanna",
classe: "Ninfa da Floresta",
vida: 50,
ataque: 70,
defesa: 40,
velocidade: 60
 },
 {
nome: "Danilo",
classe: "Bardo Baiano",
vida: 60,
ataque: 10,
defesa: 67,
velocidade: 30
 }
];

export default function App(){
  const [personagem, setPersonagem] = useState(personagens[0]);

  function gerarPersonagem() {
    const numero = Math.floor(Math.random() * personagens.length);
    setPersonagem(personagens[numero]);
  }

  return (
    <div className="app">
      <h1>🎲 Gerador de Personagem RPG</h1>

      <CharacterCard personagem={personagem} />

      <Button onClick={gerarPersonagem}>
        GERAR PERSONAGEM
      </Button>
    </div>
  );
}