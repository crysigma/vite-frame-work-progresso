import Aluno from "./components/Aluno"
import CriarAluno from "./components/CriarAluno"

export default function App(){
  return(
    <div className="container">
      <h1>Lista de alunos</h1>
      <hr/> <br/>
      <CriarAluno/>
    </div>
  )
}