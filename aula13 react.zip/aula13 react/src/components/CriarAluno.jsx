import Aluno from "./Aluno";
import { useState } from "react";

export default function CriarAluno(){
    const [nome, setNome] = useState("");
    const [idade, setIdade] = useState("");
    const [curso, setCurso] = useState("");
    const [alunos, setAlunos] = useState([]);

    function criaraluno(){
        setAlunos([...alunos, {nome, idade, curso}]);
        setNome("");
        setIdade("");
        setCurso("");

          

    }

    function limpar(){
            setAlunos([])
    }

    return(
        <div>
            <h1>Criar Alunos</h1>
            
            <input placeholder="Nome"
            value={nome}
            onChange={e => setNome(e.target.value)}
            />

            <input placeholder="Idade"
            value={idade}
            onChange={e => setIdade(e.target.value)}
            />

            <input placeholder="Curso"
            value={curso}
            onChange={e => setCurso(e.target.value)}
            />

            <button onClick={criaraluno}>Criar Aluno</button>

            <button onClick={limpar}>Limpar</button>
            
            {alunos.map((aluno, index) => (
                <Aluno
                key = {index}
                nome = {aluno.nome}
                idade = {aluno.idade}
                curso = {aluno.curso}
                />
                ))}

        </div>
    );
}

