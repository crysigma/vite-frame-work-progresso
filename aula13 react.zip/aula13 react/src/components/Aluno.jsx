export default function Aluno(props){
    return(
        <div>
            <h2>{props.nome}</h2>
            <p>{props.idade}</p>
            <p>{props.curso}</p>
        </div>
    );
}