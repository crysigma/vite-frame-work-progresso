import React, { useState } from "react";
import Filtro from "./components/filtro";
import ListaProdutos from "./components/ListaProduto";

const dados = [
  { id: 1, nome: "Teclado", preco: 100, categoria: "Periférico" },
  { id: 2, nome: "Mouse", preco: 50, categoria: "Periférico" },
  { id: 3, nome: "Monitor", preco: 800, categoria: "Tela" },
  { id: 4, nome: "HeadSet", preco: 150, categoria: "Áudio" }
];

export default function App() {
  const [produtos, setProdutos] = useState(dados);
  const [categoria, setCategoria] = useState("Todos");
  const alterarPreco = (idProduto) => {
    setProdutos(
      produtos.map((produto) => {
        if (produto.id === idProduto) {
          return { ...produto, preco: produto.preco + 10 };
        }
        return produto;
      })
    );
  };
  const produtosFiltrados = produtos.filter((produto) => {
    if (categoria === "Todos") return true;
    return produto.categoria === categoria;
  });
  return (
    <div style={{ padding: '20px', fontFamily: 'sans-serif' }}>
      <h1>Catálogo de Produtos</h1>
      <Filtro categoriaSelecionada={categoria} setCategoriaSelecionada={setCategoria} />
      <ListaProdutos produtos={produtosFiltrados} onAlterarPreco={alterarPreco} />
    </div>
  );
}
