import React from "react";

export default function CardProduto({id, nome, preco, categoria, onAlterarPreco}) {
return(
    <div style={{border: '1px,, solid, #000', padding: '10px', margin: '10px 0'}}>
<h3>{nome}</h3>
<p>Categoria: {categoria}</p>
<p>Preço: R${preco.toFixed(2)}</p>
<button onClick={() => onAlterarPreço(id)}>Aumentar Preço (+R$10)</button>
    </div>
    );
                                      }