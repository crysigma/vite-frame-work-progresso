import React from "react";

export default function Filtro({categoriaSelecionada, setCategoriaSelecionada}){
    return(
        <div style={{marginBottom: '20px'}}>
            <label>Filtrar por Categoria:</label>
            <select value={categoriaSelecionada} onChange={(e) => setCategoriaSelecionada(e.target.value)}>
                <option value="Todos">TODOS</option>
                <option value="Periférico">PERIFÉRICO</option>
                <option value="Tela">TELA</option>
                <option value="Áudio">ÁUDIO</option>
            </select>
        </div>
    );
}