import React from "react"
import CardProduto from "./CardProduto";

export default function ListaProdutos({produtos, onAlterarPreco}){
    return(
        <div>{produtos.length > 0 ? (produtos.map((produtos) => (<CardProduto key={produtos.id}
                      id={produtos.id}
                      nome={produtos.nome}
                      preco={produtos.preco}
                      categoria={produtos.categoria}
                      onAlterarPreco={onAlterarPreco}/>))) : (
                        <p>Nenhum Produto encontrado para esta categoria.</p>
                      )}
                      </div>
    );

}